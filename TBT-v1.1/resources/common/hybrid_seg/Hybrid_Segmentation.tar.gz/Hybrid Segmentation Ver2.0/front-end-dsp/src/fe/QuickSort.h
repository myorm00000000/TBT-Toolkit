#ifndef QUICKSORT_H
#define QUICKSORT_H
int Swap (float *a, float *b);
void QuickSort(float *v, int left, int right);
#endif
