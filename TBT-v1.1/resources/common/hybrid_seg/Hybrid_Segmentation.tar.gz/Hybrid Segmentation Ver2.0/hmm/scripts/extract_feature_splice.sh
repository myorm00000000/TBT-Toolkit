HCopy -C config_files/config_speech_2 -S map_table
