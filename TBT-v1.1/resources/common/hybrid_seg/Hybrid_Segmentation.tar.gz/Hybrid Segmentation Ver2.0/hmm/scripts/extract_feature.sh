HCopy -C config_files/config_speech -S map_table
